
# Design Report - Shiraz Urban Routing

## 1. Data Source and License
The road network data was obtained from OpenStreetMap using OSMnx.
The data is available under the Open Database License (ODbL).
Attribution: © OpenStreetMap contributors.

## 2. Map Type and Environment
A drivable road network was selected.
The environment is represented as a directed multigraph.
Nodes represent road intersections and edges represent road segments.

## 3. Project Area
The project covers the Shiraz urban area returned by OpenStreetMap
for the place query: Shiraz, Fars Province, Iran.

## 4. Data Requirements
The required data includes:
- Node coordinates
- Road connectivity
- Road length
- Road type
- Travel direction

## 5. 2D Grid Conversion
The road network was projected to UTM Zone 39N (EPSG:32639).
A grid with 10 x 10 meter cells was created.

Grid dimensions: 3025 rows x 2646 columns
Traversable cells: 488654
Non-traversable cells: 7515496

Road cells are represented by 1 and other cells by 0.
The grid was saved as a NumPy file and a PNG image.

## 6. Limitations
The grid rasterizes road geometries. It does not yet represent
traffic conditions, road restrictions, or all real-world obstacles.
The grid should be validated before being used for final route planning.
